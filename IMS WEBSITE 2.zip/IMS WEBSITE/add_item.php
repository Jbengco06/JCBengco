<?php
// Database connection settings
$servername = "localhost"; // Your MySQL server (use 'localhost' for local server)
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "ims_main"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $max_quantity = $_POST['max_quantity'];
    $level = $_POST['level'];
    $category = $_POST['category'];

    // SQL query to insert the new item into the database
    $sql = "INSERT INTO inventory_dashboard (ITEM_NAME, QUANTITY, MAX_QUANTITY, LEVEL, CATEGORY) 
            VALUES ('$item_name', '$quantity', '$max_quantity', '$level', '$category')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "New item added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
