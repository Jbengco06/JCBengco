<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "A_bahay0811";
$dbname = "ims_main";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch all items from the inventory
$sql = "SELECT * FROM inventory_dashboard";
$result = $conn->query($sql);

// Display the inventory items in a table
echo "<table border='1'>
        <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Max Quantity</th>
            <th>Level</th>
            <th>Category</th>
        </tr>";

if ($result->num_rows > 0) {
    // Output each row of the result
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row["ITEM_NAME"]."</td>
                <td>".$row["QUANTITY"]."</td>
                <td>".$row["MAX_QUANTITY"]."</td>
                <td>".$row["LEVEL"]."</td>
                <td>".$row["CATEGORY"]."</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No items found in inventory.";
}

// Close the connection
$conn->close();
?>
