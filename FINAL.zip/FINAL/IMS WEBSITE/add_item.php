<?php
session_start();
include ('connection_database.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $max_quantity = $_POST['max_quantity'];
    $level = $_POST['level'];
    $category = $_POST['category'];

    // SQL query with prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO inventory_dashboard (ITEM_NAME, QUANTITY, MAX_QUANTITY, LEVEL, CATEGORY) 
                            VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siiis", $item_name, $quantity, $max_quantity, $level, $category); // 's' for string, 'i' for integer

    // Execute the query
    if ($stmt->execute()) {
        echo "New item added successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and the connection
    $stmt->close();
    $conn->close();
}
?>
