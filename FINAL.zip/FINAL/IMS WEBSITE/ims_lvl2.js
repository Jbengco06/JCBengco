document.addEventListener("DOMContentLoaded", () => {
    // OPEN MODAL
    document.querySelector(".add-item").addEventListener("click", () => {
      document.getElementById("addItemModal").style.display = "flex";
    });
  
    // DELETE FUNCTION
    document.querySelectorAll(".delete").forEach(addDeleteListener);
  
    // EDIT FUNCTION
    document.querySelectorAll(".edit").forEach(addEditListener);
  });
  
  // CLOSE MODAL FUNCTION
  function closeModal() {
    document.getElementById("addItemModal").style.display = "none";
  }
  
  // ADD ITEM FUNCTION
  function addItem() {
    const itemName = document.getElementById("itemNameInput").value.trim();
    const quantity = parseInt(document.getElementById("itemQtyInput").value.trim());
    const category = document.getElementById("itemCategoryInput").value;
  
    if (!itemName || isNaN(quantity)) {
      alert("Please fill in all fields.");
      return;
    }
  
    const statusClass = quantity < 5 ? "low" : "over";
    const statusText = statusClass === "low" ? "Low Stocks" : "Over Stocks";
  
    const tbody = document.getElementById("inventory-body");
    const tr = document.createElement("tr");
  
    tr.innerHTML = `
      <td><strong>${itemName}</strong></td>
      <td>
        <span class="minus-btn" onclick="adjustQuantity(this, -1)">-</span>
        <span class="qty">${quantity}</span>
        <span class="add-btn" onclick="adjustQuantity(this, 1)">+</span>
      </td>
      <td><strong>${category}</strong></td>
      <td><span class="status ${statusClass}">${statusText}</span></td>
      <td class="actions">
        <button class="edit">✏️</button>
        <button class="delete">🗑️</button>
      </td>
    `;
  
    tbody.appendChild(tr);
    closeModal();
  
    // Reset form
    document.getElementById("itemNameInput").value = "";
    document.getElementById("itemQtyInput").value = "";
    document.getElementById("itemCategoryInput").value = "Beverages";
  
    // Reattach listeners
    tr.querySelector(".delete").addEventListener("click", () => tr.remove());
    tr.querySelector(".edit").addEventListener("click", () => {
      const itemCell = tr.children[0];
      const qtySpan = tr.querySelector(".qty");
      const categoryCell = tr.children[2];
  
      const newItem = prompt("Edit Item Name:", itemCell.textContent.trim());
      const newQty = prompt("Edit Quantity:", qtySpan.textContent.trim());
      const newCategory = prompt("Edit Category:", categoryCell.textContent.trim());
  
      if (newItem) itemCell.innerHTML = <strong>${newItem}</strong>;
      if (!isNaN(newQty) && newQty !== null) qtySpan.textContent = parseInt(newQty);
      if (newCategory) categoryCell.innerHTML = <strong>${newCategory}</strong>;
    });
  }
  
  function adjustQuantity(element, change) {
    const qtySpan = element.parentElement.querySelector(".qty");
    let currentQty = parseInt(qtySpan.textContent);
    currentQty = Math.max(0, currentQty + change);
    qtySpan.textContent = currentQty;
  
    const statusSpan = element.closest("tr").querySelector(".status");
    const statusClass = currentQty < 5 ? "low" : "over";
    statusSpan.className = `status ${statusClass};
    statusSpan.textContent = statusClass === "low" ? "Low Stocks" : "Over Stocks";
  }
  
  function addDeleteListener(button) {
    button.addEventListener("click", function () {
      const row = this.closest("tr");
      if (confirm("Are you sure you want to delete this item?")) {
        row.remove();
      }
    });
  }
  
  function addEditListener(button) {
    button.addEventListener("click", function () {
      const row = this.closest("tr");
      const itemCell = row.children[0];
      const qtySpan = row.querySelector(".qty");
      const categoryCell = row.children[2];
  
      const newItem = prompt("Edit Item Name:", itemCell.textContent.trim());
      const newQty = prompt("Edit Quantity:", qtySpan.textContent.trim());
      const newCategory = prompt("Edit Category:", categoryCell.textContent.trim());
  
      if (newItem) itemCell.innerHTML = <strong>${newItem}</strong>;
      if (!isNaN(newQty) && newQty !== null) qtySpan.textContent = parseInt(newQty);
      if (newCategory) categoryCell.innerHTML = <strong>${newCategory}</strong>;
    });
  `}
