<?php
// Database connection settings
$servername = "localhost"; // Your MySQL server (use 'localhost' for local server)
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "ims_main"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>