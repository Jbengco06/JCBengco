document.addEventListener("DOMContentLoaded", () => {
    const addModal = document.getElementById("addItemModal");
  
    // Open Modal for Adding Item
    document.getElementById("openAddModal").addEventListener("click", () => {
      toggleModalVisibility(true);
      document.getElementById("addBtn").textContent = "Add";
      document.getElementById("addBtn").removeEventListener("click", updateItem);
      document.getElementById("addBtn").addEventListener("click", addItem);
    });
  
    // Close Modal for Add Item
    document.getElementById("closeModalBtn").addEventListener("click", () => {
      toggleModalVisibility(false);
      document.getElementById("itemNameInput").focus();
    });
  });
  
  // Function to reset modal fields
  function resetModalFields() {
    document.getElementById("itemNameInput").value = "";
    document.getElementById("itemQtyInput").value = "";
    document.getElementById("maxQuantity").value = "";
    document.getElementById("itemCategoryInput").value = "Beverages";  // Default value
    document.getElementById("itemLevelCategory").value = "Level_1";  // Default value
  }
  
  // Function to toggle the visibility of the modal
  function toggleModalVisibility(isVisible) {
    const addItemModal = document.getElementById("addItemModal");
    addItemModal.style.display = isVisible ? "flex" : "none";
    if (!isVisible) {
      resetModalFields(); // Reset fields when closing modal
    }
  }
  
  // Add Item function
  function addItem() {
    const itemName = document.getElementById("itemNameInput").value.trim();
    const quantity = parseInt(document.getElementById("itemQtyInput").value.trim());
    const maxQty = parseInt(document.getElementById("maxQuantity").value.trim());
    const category = document.getElementById("itemCategoryInput").value;
  
    // Updated validation: Checking if all fields are valid
    if (!itemName || isNaN(quantity) || isNaN(maxQty) || maxQty <= 0 || isNaN(quantity) || quantity <= 0) {
      alert("Please fill in all fields correctly.");
      return;
    }
  
  
    const { statusText, statusClass } = calculateStatus(quantity, maxQty);
  
    const tbody = document.getElementById("inventory-body");
    const tr = document.createElement("tr");
    tr.dataset.max = maxQty;
    tr.dataset.itemName = itemName; 
    tr.dataset.category = category;
    tr.dataset.quantity = quantity;
  
    tr.innerHTML = `
      <td><strong>${itemName}</strong></td>
      <td>
        <button class="adjust-btn minus-btn" onclick="adjustQuantity(this, -1)">-</button>
        <input type="number" class="qty-input" value="${quantity}" min="0" onchange="updateStatus(this)" />
        <button class="adjust-btn add-btn" onclick="adjustQuantity(this, 1)">+</button>
      </td>
      <td><strong>${category}</strong></td>
      <td><span class="status ${statusClass}">${statusText}</span></td>
      <td class="actions">
        <button class="edit" onclick="openEditModal(this.closest('tr'))">✏️</button>
        <button class="delete" onclick="deleteItem(this.closest('tr'))">🗑️</button>
      </td>
    `;
  
    tbody.appendChild(tr);
  
    // Close the modal after adding the item
    toggleModalVisibility(false);
    resetModalFields();
  }
  
  // Function to handle quantity change (manually inputted)
  function updateStatus(input) {
    const tr = input.closest("tr");
    const qty = parseInt(input.value);
    const max = parseInt(tr.dataset.max);

    // Update the data-quantity in the row's dataset
    tr.dataset.quantity = qty;

    const { statusText, statusClass } = calculateStatus(qty, max);

    const statusSpan = tr.querySelector(".status");
    statusSpan.className = `status ${statusClass}`;
    statusSpan.textContent = statusText;

    // Also, ensure that the updated value is reflected in the modal input field
    document.getElementById("itemQtyInput").value = qty;
}


// Function to adjust the quantity using the + and - buttons
function adjustQuantity(element, change) {
  const input = element.closest("td").querySelector(".qty-input");
  let qty = parseInt(input.value);
  qty = Math.max(0, qty + change); // Prevent negative values
  input.value = qty;

  const tr = input.closest("tr");
  tr.dataset.quantity = qty;  // Ensure data-quantity reflects the updated value

  const max = parseInt(tr.dataset.max);
  const { statusText, statusClass } = calculateStatus(qty, max);

  const statusSpan = tr.querySelector(".status");
  statusSpan.className = `status ${statusClass}`;
  statusSpan.textContent = statusText;
}
  
  // Open the Edit Modal and populate it with the item's data
  // Open the Edit Modal and populate it with the item's data
// Open the Edit Modal and populate it with the item's data
// Open Edit Modal and populate it with the item's data
function openEditModal(row) {
  // Retrieve data stored in the row (itemName, quantity, maxQty, category)
  const itemName = row.dataset.itemName;
  const quantity = row.dataset.quantity;  // This should reflect the updated quantity
  const maxQuantity = row.dataset.max;
  const category = row.dataset.category;

  // Open the modal for editing
  const addItemModal = document.getElementById("addItemModal");
  addItemModal.style.display = "flex";

  // Log to check the quantity being passed
  console.log("Opening Edit Modal for: ", itemName, "Quantity: ", quantity);

  // Populate modal with current data
  document.getElementById("itemNameInput").value = itemName;
  document.getElementById("itemQtyInput").value = quantity;  // Ensure this reflects the updated quantity
  document.getElementById("maxQuantity").value = maxQuantity;
  document.getElementById("itemCategoryInput").value = category;

  // Change the modal button text to "Update"
  const addBtn = document.getElementById("addBtn");
  addBtn.textContent = "Update"; // Change the button text
  addBtn.removeEventListener("click", addItem); // Remove the add item event listener
  addBtn.addEventListener("click", function() {
    updateItem(row); // Call update function when "Update" is clicked
  });
}

// Update Function
  function updateItem(row) {
    // Get the updated values from modal fields
    const itemName = document.getElementById("itemNameInput").value.trim();
    const quantity = parseInt(document.getElementById("itemQtyInput").value.trim());
    const maxQty = parseInt(document.getElementById("maxQuantity").value.trim());
    const category = document.getElementById("itemCategoryInput").value;
  
    // Check for valid quantity and maxQuantity
    if (!itemName || isNaN(quantity) || isNaN(maxQty) || quantity <= 0 || maxQty <= 0) {
      alert("Please fill in all fields correctly.");
      return;
    }
  
    // If validation is passed, update the row's data
    row.dataset.itemName = itemName;
    row.dataset.quantity = quantity;
    row.dataset.max = maxQty;
    row.dataset.category = category;
  
    // Update the row's visible content
    row.querySelector("td:nth-child(1)").innerHTML = `<strong>${itemName}</strong>`;
    row.querySelector(".qty-input").value = quantity;  // Ensure the updated quantity is reflected in the input
    row.querySelector("td:nth-child(3)").innerHTML = `<strong>${category}</strong>`;
  
    // Calculate stock status
    const { statusText, statusClass } = calculateStatus(quantity, maxQty);
  
    // Update the stock status
    const statusSpan = row.querySelector(".status");
    statusSpan.className = `status ${statusClass}`;
    statusSpan.textContent = statusText;
  
    // Close the modal after updating
    document.getElementById("addItemModal").style.display = "none";
  
    // Reset modal fields for future use
    resetModalFields();
  
    // Reset Add button functionality
    const addBtn = document.getElementById("addBtn");
    addBtn.textContent = "Add";  // Reset to "Add" for next item
    addBtn.removeEventListener("click", updateItem);  // Remove the update listener
    addBtn.addEventListener("click", addItem);  // Reattach the add listener
  }
  
  
  
  // Function to delete an item from the table
  function deleteItem(row) {
    row.remove();
  }
  
  // Function to calculate stock status
  function calculateStatus(quantity, maxQuantity) {
    const percent = (quantity / maxQuantity) * 100;
  
    if (percent <= 30) {
      return { statusText: "Low Stock", statusClass: "low" };
    } else if (percent <= 100) {
      return { statusText: "In Stock", statusClass: "medium" };
    } else {
      return { statusText: "Over Stock", statusClass: "high" };
    }
  }
  